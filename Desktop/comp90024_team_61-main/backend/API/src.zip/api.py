import os
from flask import Flask, request, jsonify
from elasticsearch import Elasticsearch

app = Flask(__name__)

ES_HOST = "https://elasticsearch-master.elastic.svc:9200"
ES_USER = os.getenv("ES_USERNAME")
ES_PASS = os.getenv("ES_PASSWORD")

es = Elasticsearch(
    ES_HOST,
    basic_auth=(ES_USER, ES_PASS),
    headers={"Accept": "application/vnd.elasticsearch+json;compatible-with=8"},
    verify_certs=False
)

@app.route('/search_posts', methods=['GET'])
def search():
    keyword = request.args.get("keyword", "")
    index = request.args.get("index", "reddit_comments")
    # Query for ElasticSearch
    try:
        if keyword:
            query = {
                "query": {
                    "match": {
                        "content": keyword
                    }
                }
            }

        else:
            query = {
                "query": {
                    "match_all": {}
                }
            }

        all_hits = []

        # Initial search with scroll
        result = es.search(index=index, body=query, scroll='2m', size=1000)
        scroll_id = result.get('_scroll_id')
        hits = result['hits']['hits']
        all_hits.extend(hits)

        # Scroll loop
        while hits:
            result = es.scroll(scroll_id=scroll_id, scroll='2m')
            scroll_id = result.get('_scroll_id')
            hits = result['hits']['hits']
            if not hits:
                break
            all_hits.extend(hits)

        es.clear_scroll(scroll_id=scroll_id)

        return jsonify([hit["_source"] for hit in all_hits])

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
